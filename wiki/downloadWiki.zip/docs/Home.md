**Online Banking Reference Architecture**
This reference architecture is designed to show banks how to leverage Microsoft technologies and open industry standards such as IFX and OFX. It provides a simplified approach to building Online Banking Portals using SharePoint technologies. The portal is comprised of a set of web parts that are based on Windows Workflow Foundation (WF) that involves invoking a series of web services that queries the central repository (DDA/SDA) that stores Customer data. Another component is the Online banking reports which are exported in an Open XML format. The Word document which is OFX based allows banks to leverage exisitng export feeds to a popular desktop word processor, Microsoft Word. 

Components include: 
* Site Template
* IFX Web Services
* OFX Interfaces
* Transaction Summary, Transaction History Web Parts and BDC Enitites
* Word Based Consumer Reports based on Open XML and OFX standards. 
